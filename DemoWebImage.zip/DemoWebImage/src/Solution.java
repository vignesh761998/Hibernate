import java.io.File;
import java.io.FileInputStream;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.model.Users;

public class Solution {
	public static void main(String args[]) {
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session session=sf.openSession();
		session.beginTransaction();
		File file=new File("C:/Users/students/Downloads/image.jpg");
		byte[] bFile = new byte[(int) file.length()];
		try {
		     FileInputStream fileInputStream = new FileInputStream(file);
		     //convert file into array of bytes
		     fileInputStream.read(bFile);
		     fileInputStream.close();
	        } catch (Exception e) {
	        	e.printStackTrace();
	        }
		Users u=new Users();
		u.setUsername("vignesh");
		u.setPassword("1234");
		u.setPhoto(bFile);
		session.save(u);
		session.getTransaction().commit();
		session.close();
		
	}
}
